// Copyright 2024 Dasky (@daskygit)
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#include "test_common.h"

#define POINTING_DEVICE_ROTATION_270
